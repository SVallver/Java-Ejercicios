public class Ejercicio3 {
    public static void main(String[] args) {
        String[] nombres = {"Sergio","Paula","Mario","Alba"};
        var texto = "";
        for(var i = 0; i < nombres.length; i++){
            texto += nombres[i] + ",";
        }
        System.out.println(texto);
    }
}