import java.io.FileInputStream;
import java.io.InputStream;
import java.io.PrintStream;
import java.util.*;
import java.util.HashMap;

public class Ej789 {
    public static class StringReverse {
        public static String reverse(String texto) {
            if (texto.isEmpty()) {
                return texto;
            } else {
                return reverse(texto.substring(1)) + texto.charAt(0);
            }
        }
        public static void main(String[] args) {
            StringReverse obj = new StringReverse();
            String result = obj.reverse("Hola mundo");
            System.out.println(result);
        }
    }
    public static class ArrayUnidimensional {

        public static void main(String[] args) {

            String textos[] = {"Lunes", "Martes", "Miercoles", "Jueves", "Viernes"};

            for (String i : textos) {
                System.out.print(i + " ");
            }
        }
    }
    public static class ArrayBidimensional {

        public static void main(String[] args) {

            int[][] numerosEnteros = {
                    {16, 29, 32},
                    {78, 61, 53}
            };

            for (int i = 0; i < numerosEnteros.length; i++) {
                for (int j = 0; j < numerosEnteros[i].length; j++) {

                    System.out.println("En la Fila: " + (i + 1) + " y Columna: " + (j + 1) +
                            ", el valor es: " + numerosEnteros[i][j] + "\n");
                }
            }
        }
    }
    public static class DatoVector {

        public static void main(String[] args) {

            Vector<Integer> vector = new Vector(128);
            vector.add(10);
            vector.add(23);
            vector.add(37);
            vector.add(49);
            vector.add(62);

            System.out.println(vector);

            vector.remove(2);
            vector.remove(1);

            System.out.println(vector);

            System.out.println("Respuesta: se desperdicia mucha memoria ya que cada vez que sobrepasa el limite se duplica la capacidad");
        }
    }
    public static class ArrayListString {

        public static void main(String[] args) {

            ArrayList<String> lista = new ArrayList<>();
            lista.add("Sergio");
            lista.add("Paula");
            lista.add("Alex");
            lista.add("Marta");

            LinkedList<String> linkedlist = new LinkedList<>();

            for (int i = 0; i < lista.size(); i++) {
                linkedlist.add(i, lista.get(i));
            }

            System.out.println("Array:");
            for (String elementos : lista) {
                System.out.print(elementos + ", ");
            }

            System.out.println("\nLinkedList:");
            for (String elementos : linkedlist) {
                System.out.print(elementos + ", ");
            }
        }
    }
    public static class ArrayListInt {

        public static void main(String[] args) {

            ArrayList<Integer> lista = new ArrayList<>();

            for (int i = 1; i <= 10; i++) {
                lista.add(i);

                for (int num = 0; num < lista.size(); num++) {

                    if (lista.get(num) % 2 == 0) {
                        lista.remove(num);
                    }
                }
            }

            System.out.println(lista);
        }
    }
    public static class DividePorCero {

        private static int Dividir(int num1, int num2) throws ArithmeticException {
            return num1 / num2;
        }

        public static void main(String[] args) {

            Scanner scanner = new Scanner(System.in);
            System.out.println("Indica los numeros a dividir: ");
            System.out.print("primer numero: ");
            int num1 = scanner.nextInt();
            System.out.print("segundo numero: ");
            int num2 = scanner.nextInt();
            try {
                System.out.println("Resultado: " + Dividir(num1, num2));
            } catch (ArithmeticException e) {
                System.out.println("no puede hacerse");
            } finally {
                System.out.println("Demo de código");
            }
        }
    }

    public static class CopiarFicheros {

        public static void main(String[] args) {

            Scanner scanner = new Scanner(System.in);
            System.out.println("Introduce el fichero de origen: ");
            String fileIn = scanner.nextLine();
            System.out.println("Introduce el fichero de destino: ");
            String fileOut = scanner.nextLine();
            copiar(fileIn, fileOut);
        }
        private static void copiar(String fileIn, String fileOut) {
            try {
                InputStream in = new FileInputStream(fileIn);
                byte[] datos = in.readAllBytes();
                in.close();

                PrintStream out = new PrintStream(fileOut);
                out.write(datos);
                out.close();
            } catch (Exception e) {
                System.out.println("Excepcion: " + e.getMessage());
            }
        }
    }

    public static class Ejerciciopropio {
        public static void main(String[] args) {

            int Edad = 0;
            String Nombre = " ";
            HashMap<Integer,String> data = new HashMap<>();
            int arrayEdad[]= new int[3];
            String arrayNombre[]= new String[3];
            int older = 0;

            try{

                Scanner ageIn1 = new Scanner(System.in);
                System.out.println("Edad del primer usuario");
                Edad = ageIn1.nextInt();
                Scanner nameIn1 = new Scanner(System.in);
                System.out.println("Nombre del primer usuario");
                Nombre = nameIn1.next();
                data.put(Edad, Nombre);
                arrayEdad[0]= Edad;
                arrayNombre[0]= Nombre;

                Scanner EdadIn2 = new Scanner(System.in);
                System.out.println("Edad del segundo usuario");
                Edad = EdadIn2.nextInt();
                Scanner NombreIn2 = new Scanner(System.in);
                System.out.println("Nombre del segundo usuario");
                Nombre = NombreIn2.next();
                data.put(Edad, Nombre);
                arrayEdad[1]= Edad;
                arrayNombre[1]= Nombre;

                Scanner EdadIn3 = new Scanner(System.in);
                System.out.println("Edad del tercer usuario");
                Edad = EdadIn3.nextInt();
                Scanner NombreIn3 = new Scanner(System.in);
                System.out.println("Nombre del tercer usuario");
                Nombre = NombreIn3.next();
                data.put(Edad, Nombre);
                arrayEdad[2]= Edad;
                arrayNombre[2]= Nombre;

            }catch (InputMismatchException e){
                System.out.println("Datos incorrectos");
            }

            System.out.println("Los usuarios guardados en el mapa son:\n" + data + "\n");

            for(int i=0; i<arrayEdad.length && i<arrayNombre.length; i++){
                if(arrayEdad[i]>older){
                    older = arrayEdad[i];
                }
            }

            for(HashMap.Entry <Integer,String> pair : data.entrySet()){
                if(older == pair.getKey()){
                    System.out.println("El mayor tiene " + pair.getKey() + " años y se llama " + pair.getValue());
                }
            }
        }
    }
}
