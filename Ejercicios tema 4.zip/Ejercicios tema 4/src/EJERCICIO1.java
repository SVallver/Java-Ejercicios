public class EJERCICIO1 {
    public static void main(String[] args) {
        var numero = 0;
        if (numero == 0) {
            System.out.println("Es 0");
        } else if (numero >= 0) {
            System.out.println("Es positivo");
        } else {
            System.out.println("Es negativo");
        }
    }
}
