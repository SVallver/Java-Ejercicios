public class EJERCICIO4 {
    public static void main(String[] args) {
        for (int contador = 0; contador <= 3; contador++)
            System.out.println(contador);
    }
}
