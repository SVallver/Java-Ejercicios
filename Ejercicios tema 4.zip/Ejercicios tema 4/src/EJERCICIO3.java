public class EJERCICIO3 {
    public static void main(String[] args) {
        int contador = 0;
        do {
            System.out.println(contador);
            contador++;
        } while (contador < 3);
    }
}
