public class EJERCICIO5 {
    public static void main(String[] args) {
        var estacion = "VERANO";
        switch(estacion){
            case"VERANO":
                System.out.println("es Verano");
                break;
            case"PRIMAVERA":
                System.out.println("es Primavera");
                break;
            case"OTOÑO":
                System.out.println("es Otoño");
                break;
            case"INVIERNO":
                System.out.println("es Invierno");
                break;
            default:
                System.out.println(estacion);
        }
    }
}





