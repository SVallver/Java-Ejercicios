public class CocheCRUDImpl implements CocheCRUD {
        public void CocheCRUD(){
        }
        public void save() {
            System.out.println("Guardado");
        }
        public void findAll() {
            System.out.println("Todos los coches");
        }
        public void delete() {
            System.out.println("Borrado");
        }
}
