public class Main {
    public static void main(String[] args){
        Persona persona = new Persona();

        persona.setEdad(28);
          System.out.println(persona.getEdad());
        persona.setNombre("Sergio");
          System.out.println(persona.getNombre());
        persona.setTelefono(636050162);
          System.out.println(persona.getTelefono());
    }
}
class Persona{
    private int edad;
    private String nombre;
    private int telefono;

    public void setEdad(int edad){
        this.edad = edad;
    }
    public void setNombre(String nombre){
        this.nombre = nombre;
    }
    public void setTelefono(int telefono){
        this.telefono = telefono;
    }
    public int getEdad(){
        return this.edad;
    }
    public String getNombre(){
        return this.nombre;
    }
    public int getTelefono(){
        return this.telefono;
    }
}