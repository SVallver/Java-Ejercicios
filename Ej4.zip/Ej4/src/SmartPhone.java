public class SmartPhone extends SmartDevice {
    public double pixelcamara;
    public String flash;
    public int ancho;
    public int alto;

    public SmartPhone(){

    }
    public SmartPhone(String marca, String modelo, String color, int memoria, boolean bluethoot, boolean wifi, double precio,
                      double pixelcamara, String flash, int ancho, int alto) {
        super(marca, modelo, color, memoria, bluethoot, wifi, precio);
        this.pixelcamara = pixelcamara;
        this.flash = flash;
        this.ancho = ancho;
        this.alto = alto;
    }
}
