public class SmartDevice {
    public String marca;
    public String modelo;
    public String color;
    public int memoria;
    public boolean bluethoot;
    public boolean wifi;
    public double precio;

    public SmartDevice (){

    }
    public SmartDevice( String marca, String modelo, String color, int memoria, boolean bluethoot,
                        boolean wifi, double precio) {
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
        this.memoria = memoria;
        this.bluethoot = bluethoot;
        this.wifi = wifi;
        this.precio = precio;
    }
}
