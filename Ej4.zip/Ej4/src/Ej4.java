public class Ej4 {
    public static void main(String[] args) {
        SmartPhone xiaomi = new SmartPhone("Xiaomi", "Redmi 10C","azul", 128, true, true,
                132.95, 50,  "led", 4, 7);

        System.out.println(xiaomi.marca +" "+ xiaomi.modelo +" "+ xiaomi.color +" Memoria de "+ xiaomi.memoria +"GB, bluethoot: "+
                xiaomi.bluethoot +", wifi: "+ xiaomi.wifi +", camara "+ xiaomi.pixelcamara+
                ", flash "+ xiaomi.flash+", ancho " +xiaomi.ancho+", alto "+xiaomi.alto +", precio "+ xiaomi.precio +" $.");

        SmartWatch xiaomiwatch = new SmartWatch("Xiaomi","Redmi Lite 2","negro",64,true,
                false,55.99);
        System.out.println("SmartWatch marca " +xiaomiwatch.marca+", modelo "+xiaomiwatch.modelo+", color " + xiaomiwatch.color+
                ", RAM de "+xiaomiwatch.memoria+"GB, bluethoot: "+xiaomiwatch.bluethoot+", wifi: "+
                xiaomiwatch.wifi+", precio: "+ xiaomiwatch.precio +" $.");
    }
}