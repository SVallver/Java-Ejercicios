public class SmartWatch extends SmartDevice{
    public SmartWatch(String marca, String modelo, String color, int memoria, boolean bluethoot,
                      boolean wifi, double precio) {
        super(marca, modelo, color, memoria, bluethoot, wifi, precio);

    }
}
