public class Ej2 {

    public static void main(String[] args) {

        double resultado = PrecioTotal(79.99,0.20);
        System.out.println(resultado);
    }
    static double PrecioTotal( double precio, double iva ) {
        return (precio * iva) + precio;
    }

}